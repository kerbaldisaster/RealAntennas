﻿using System.Text;
using UnityEngine;
using ClickThroughFix;
using System.Linq;

namespace RealAntennas
{
    /// <summary>
    /// RA Subnets (Constellations)
    ///
    /// Policies:
    /// - Link-to-link enforcement only (no end-to-end subnet state).
    /// - 32 subnets (0..31) encoded in a 32-bit mask.
    /// - Subnet 0 is Public wildcard, BUT Public is mutually exclusive with non-public selection:
    ///     * If any non-public subnet is selected, Public is cleared.
    ///     * If no non-public subnet is selected, Public is enabled.
    /// - Halo rendering:
    ///     * No halo is drawn for Public links (subnet 0), preserving stock/current RA visuals
    ///       unless user opts into non-public subnets.
    /// </summary>
    public static class RASubnets
    {
        public const int MaxSubnets = 32;
        public const int PublicSubnet = 0;
        public const uint PublicBit = 1u << PublicSubnet;

        // Wired at runtime from MapUI.Settings by RACommNetUI
        public static bool EnableSubnets = true;

        /// <summary>
        /// Normalize mask to enforce mutual exclusivity rule:
        /// - If any non-public bits are set, Public bit is cleared.
        /// - If no non-public bits are set, Public bit is set.
        /// </summary>
        public static uint NormalizeMask(uint mask)
        {
            uint nonPublic = mask & ~PublicBit;
            if (nonPublic != 0u) return nonPublic; // explicit non-public => public off
            return PublicBit;                      // otherwise => public on
        }

        public static bool IsPublicOnly(uint mask) => NormalizeMask(mask) == PublicBit;

        public static int LowestSetBit(uint mask)
        {
            if (mask == 0u) return -1;
            int bit = 0;
            while ((mask & 1u) == 0u) { mask >>= 1; bit++; }
            return bit;
        }

        /// <summary>
        /// Link-to-link subnet match. Public-only matches anything.
        /// If subnets disabled => always match.
        /// </summary>
        public static bool SubnetMatch(uint aMask, uint bMask)
        {
            if (!EnableSubnets) return true;

            uint a = NormalizeMask(aMask);
            uint b = NormalizeMask(bMask);

            // Public-only is wildcard
            if (a == PublicBit || b == PublicBit) return true;

            return (a & b) != 0u;
        }

        /// <summary>
        /// Pick a single subnet id to label/color a link.
        /// Rules:
        /// - If either side is Public-only and the other has non-public bits, return the other's lowest bit.
        /// - Else return the lowest set bit of the intersection.
        /// - If no intersection (shouldn't happen if caller ensured match), return Public.
        /// </summary>
        public static int PickLinkSubnet(uint aMask, uint bMask)
        {
            if (!EnableSubnets) return PublicSubnet;

            uint a = NormalizeMask(aMask);
            uint b = NormalizeMask(bMask);

            if (a == PublicBit && b == PublicBit) return PublicSubnet;
            if (a == PublicBit) return LowestSetBit(b);
            if (b == PublicBit) return LowestSetBit(a);

            uint inter = (a & b);
            int s = LowestSetBit(inter);
            return (s >= 0) ? s : PublicSubnet;
        }

        /// <summary>
        /// Display summary for PAW. Public is shown only when no non-public subnets are selected.
        /// </summary>
        public static string MaskSummary(uint mask)
        {
            uint normalizedMask = NormalizeMask(mask);
            if (normalizedMask == PublicBit) return "Public";

            var sb = new StringBuilder("SN:");
            bool first = true;
            for (int subnetbit = 1; subnetbit < 32; subnetbit++)
            {
                if ((normalizedMask & (1u << subnetbit)) != 0u)
                {
                    if (!first) sb.Append(",");
                    sb.Append(subnetbit);
                    first = false;
                }
            }
            return sb.ToString();
        }

        /// <summary>
        /// Deterministic subnet color. Public (0) is gray, but note: halo is not drawn for Public.
        /// </summary>
        public static Color SubnetColor(int subnet, float alpha = 1f)
        {
            if (subnet == PublicSubnet)
            {
                var c = new Color(0.85f, 0.85f, 0.85f, alpha);
                return c;
            }

            // Golden ratio hue hashing
            float hue = Mathf.Repeat(subnet * 0.61803398875f, 1f);
            Color c2 = Color.HSVToRGB(hue, 0.80f, 1.00f);
            c2.a = alpha;
            return c2;
        }

        // ------------------ Checkbox GUI (multi-select) ------------------

        public class SubnetEditorGUI : MonoBehaviour
        {
            const string GUIName = "Antenna Subnets";
            Rect Window = new Rect(80, 140, 400, 500);
            Vector2 scroll;

            public ModuleRealAntenna parent;
            public RealAntenna antenna;

            uint workingMask;

            public void Init(ModuleRealAntenna m, RealAntenna a)
            {
                parent = m;
                antenna = a;
                workingMask = NormalizeMask(a?.SubnetMask ?? PublicBit);
            }

            public void OnGUI()
            {
                GUI.skin = HighLogic.Skin;
                Window = ClickThruBlocker.GUILayoutWindow(GetHashCode(), Window, Draw, GUIName, HighLogic.Skin.window);
            }

            void Draw(int id)
            {
                GUILayout.BeginVertical(HighLogic.Skin.box);
                GUILayout.Label($"Antenna: {antenna?.Name ?? "(null)"}");
                GUILayout.Label($"Band: {antenna?.RFBand?.name ?? "(null)"}");
                GUILayout.Label($"Selected: {MaskSummary(workingMask)}");
                GUILayout.EndVertical();

                GUILayout.Space(6);

                scroll = GUILayout.BeginScrollView(scroll, GUILayout.Height(320));

                // Public checkbox (mutually exclusive)
                bool isPublic = (NormalizeMask(workingMask) == PublicBit);
                bool publicNext = GUILayout.Toggle(isPublic, "Subnet 0 (Public wildcard)");
                if (publicNext && !isPublic)
                {
                    // Clicking public => deselect all non-public
                    workingMask = PublicBit;
                }

                // Non-public checkboxes
                var registry = SubnetManagerScenario.Instance;

                if (registry != null)
                {
                    foreach (var kvp in registry.Subnets.AsEnumerable().OrderBy(k => k.Key))
                    {
                        int i = kvp.Key;
                        bool on = (workingMask & (1u << i)) != 0u;
                        bool next = GUILayout.Toggle(on, kvp.Value);

                        if (next != on)
                        {
                            if (next)
                            {
                                workingMask &= ~PublicBit;
                                workingMask |= (1u << i);
                            }
                            else
                            {
                                workingMask &= ~(1u << i);
                                if ((workingMask & ~PublicBit) == 0u)
                                    workingMask = PublicBit;
                            }
                        }
                    }
                }

                GUILayout.EndScrollView();

                GUILayout.Space(8);

                GUILayout.BeginHorizontal();
                if (GUILayout.Button("Apply"))
                {
                    uint finalMask = NormalizeMask(workingMask);

                    if (antenna != null) antenna.SubnetMask = finalMask;

                    if (parent != null)
                    {
                        parent.SubnetMask = finalMask;
                        parent.SubnetSummary = MaskSummary(finalMask);

                        // Force update of vessel/network
                        if (HighLogic.LoadedSceneIsEditor || HighLogic.LoadedSceneIsFlight)
                            GameEvents.onVesselWasModified.Fire(parent.vessel);

                        MonoUtilities.RefreshPartContextWindow(parent.part);
                    }

                    Close();
                }

                if (GUILayout.Button("Close"))
                {
                    Close();
                }
                GUILayout.EndHorizontal();

                GUI.DragWindow();
            }
            public static void Show(ModuleRealAntenna m, RealAntenna a)
            {
                if (m == null || a == null)
                {
                    Debug.LogWarning("[RealAntennas] SubnetEditorGUI.Show called without antenna context.");
                    return;
                }

                GameObject go = new GameObject("RA.SubnetEditor");
                DontDestroyOnLoad(go);

                var ui = go.AddComponent<SubnetEditorGUI>();
                ui.Init(m, a);
            }
            void Close()
            {
                Destroy(this);
                gameObject.DestroyGameObject();
            }
        }
    }
}
