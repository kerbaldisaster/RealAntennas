﻿// =========================
// SubnetManagerUI.cs
// =========================

using ClickThroughFix;
using KSP.UI.Screens;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEngine;

namespace RealAntennas
{
    #region SubnetManagerLauncher: KSPAddon to launch the UI and manage its lifecycle
    [KSPAddon(KSPAddon.Startup.AllGameScenes, false)]
    internal class SubnetManagerLauncher : MonoBehaviour
    {
        private const string icon = "RealAntennas/dish";
        private ApplicationLauncherButton button;

        private void Awake()
        {
            GameEvents.onGUIApplicationLauncherReady.Add(OnGuiAppLauncherReady);
            GameEvents.onGameSceneLoadRequested.Add(OnSceneChange);
        }

        private void OnDestroy()
        {
            GameEvents.onGUIApplicationLauncherReady.Remove(OnGuiAppLauncherReady);
            GameEvents.onGameSceneLoadRequested.Remove(OnSceneChange);

            if (button != null && ApplicationLauncher.Instance != null)
                ApplicationLauncher.Instance.RemoveModApplication(button);
        }

        private void OnSceneChange(GameScenes scene)
        {
            SubnetManagerWindow.Hide();
        }

        private void OnGuiAppLauncherReady()
        {
            if (button != null || ApplicationLauncher.Instance == null)
                return;

            try
            {
                button = ApplicationLauncher.Instance.AddModApplication(
                    ShowWindow,
                    HideWindow,
                    null,
                    null,
                    null,
                    null,
                    ApplicationLauncher.AppScenes.ALWAYS & ~ApplicationLauncher.AppScenes.MAINMENU,
                    GameDatabase.Instance.GetTexture(icon, false));
            }
            catch (Exception ex)
            {
                Debug.LogError("[SubnetManagerUI] failed to register toolbar button");
                Debug.LogException(ex);
            }
        }

        private void ShowWindow()
        {
            SubnetManagerWindow.Show();
        }


        private void HideWindow()
        {
            SubnetManagerUI ui = FindObjectOfType<SubnetManagerUI>();
            if (ui != null)
                ui.Visible = false;
        }
    }

    internal static class SubnetManagerWindow
    {
        private static GameObject windowGO;

        public static bool IsVisible
        {
            get
            {
                SubnetManagerUI ui = windowGO != null ? windowGO.GetComponent<SubnetManagerUI>() : null;
                return ui != null && ui.Visible;
            }
        }

        public static SubnetManagerUI Acquire()
        {
            if (windowGO == null)
            {
                windowGO = new GameObject("RealAntennas.SubnetManager");
                UnityEngine.Object.DontDestroyOnLoad(windowGO);
                windowGO.AddComponent<SubnetManagerUI>();
            }
            return windowGO.GetComponent<SubnetManagerUI>();
        }


        public static void Show()
        {
            SubnetManagerUI ui = Acquire();
            ui.ResetSelection();
            ui.Visible = true;
        }

        public static void Hide()
        {
            if (windowGO == null)
                return;

            SubnetManagerUI ui = windowGO.GetComponent<SubnetManagerUI>();
            if (ui != null)
                ui.Visible = false;
        }
    }
    #endregion

    #region Scenario Persistence: KSPScenarioModule to persist subnet overrides and names
    // -------------------------------
    // Scenario persistence for ground station antenna subnet overrides
    // -------------------------------
    [KSPScenario(ScenarioCreationOptions.AddToAllGames | ScenarioCreationOptions.AddToAllMissionGames,
        new[] { GameScenes.FLIGHT, GameScenes.TRACKSTATION, GameScenes.SPACECENTER, GameScenes.EDITOR })]
    internal class SubnetManagerScenario : ScenarioModule
    {
        public static SubnetManagerScenario Instance { get; private set; }
        private readonly Dictionary<string, uint> groundStationAntennaOverrides = new Dictionary<string, uint>();
        private readonly Dictionary<int, string> subnetNames = new Dictionary<int, string>();
        public IReadOnlyDictionary<int, string> Subnets => subnetNames;
        public bool HasSubnet(int bit) => subnetNames.ContainsKey(bit);
        public void AddSubnet(int bit, string name) => subnetNames[bit] = name;
        public void RenameSubnet(int bit, string name) { if (subnetNames.ContainsKey(bit)) subnetNames[bit] = name; }
        private static bool refreshScheduled;

        #region Scenario: Overrides for persistence
        public override void OnAwake()
        {
            base.OnAwake();
            Instance = this;
        }

        public override void OnLoad(ConfigNode node)
        {
            base.OnLoad(node);
            groundStationAntennaOverrides.Clear();
            if (node == null)
                return;

            foreach (ConfigNode child in node.GetNodes("GroundStationAntennaSubnetOverride"))
            {
                string key = child.GetValue("key") ?? string.Empty;
                string maskValue = child.GetValue("mask") ?? "0";
                if (string.IsNullOrEmpty(key))
                    continue;
                if (!TryParseMask(maskValue, out uint mask))
                    continue;
                groundStationAntennaOverrides[key] = RASubnets.NormalizeMask(mask);
            }

            subnetNames.Clear();
            foreach (ConfigNode sn in node.GetNodes("SUBNET"))
            {
                int bit;
                if (!int.TryParse(sn.GetValue("bit"), out bit))
                    continue;

                string name = sn.GetValue("name");
                if (!string.IsNullOrEmpty(name))
                    subnetNames[bit] = name;
            }

            ApplyRuntimeOverrides();
        }

        public override void OnSave(ConfigNode node)
        {
            base.OnSave(node);
            if (node == null)
                return;

            foreach (KeyValuePair<string, uint> kvp in groundStationAntennaOverrides)
            {
                ConfigNode child = node.AddNode("GroundStationAntennaSubnetOverride");
                child.AddValue("key", kvp.Key);
                child.AddValue("mask", kvp.Value);
            }

            foreach (var kvp in subnetNames)
            {
                ConfigNode sn = node.AddNode("SUBNET");
                sn.AddValue("bit", kvp.Key);
                sn.AddValue("name", kvp.Value);
            }
        }
        #endregion

        #region Scenario: Ground Station Overrides
        public bool TryGetGroundStationAntennaOverride(string stationName, int antennaIndex, out uint mask)
        {
            return groundStationAntennaOverrides.TryGetValue(BuildGroundStationKey(stationName, antennaIndex), out mask);
        }

        public void SetGroundStationAntennaOverride(string stationName, int antennaIndex, uint mask)
        {
            groundStationAntennaOverrides[BuildGroundStationKey(stationName, antennaIndex)] = RASubnets.NormalizeMask(mask);
            ApplyRuntimeOverrides();
            RequestNetworkRefreshDeferred();
        }

        public void ApplyRuntimeOverrides()
        {
            if (RACommNetScenario.GroundStations == null)
                return;

            foreach (KeyValuePair<string, Network.RACommNetHome> kvp in RACommNetScenario.GroundStations)
            {
                Network.RACommNetHome station = kvp.Value;
                if (station == null || station.Comm == null)
                    continue;

                for (int i = 0; i < station.Comm.RAAntennaList.Count; i++)
                {
                    if (TryGetGroundStationAntennaOverride(station.nodeName, i, out uint mask))
                        station.Comm.RAAntennaList[i].SubnetMask = mask;
                }
            }
        }

        #endregion

        #region Scenario: Network Refresh
        public static void RequestNetworkRefresh()
        {
            RACommNetScenario scen = RACommNetScenario.Instance as RACommNetScenario;
            if (scen != null && scen.Network != null)
                scen.Network.InvalidateCache();

            if (FlightGlobals.ActiveVessel != null)
                GameEvents.onVesselWasModified.Fire(FlightGlobals.ActiveVessel);
        }

        #endregion

        #region Scenario: Parsing / Keys
        public static bool TryParseMask(string value, out uint mask)
        {
            mask = 0u;
            if (string.IsNullOrEmpty(value))
                return false;

            value = value.Trim();
            if (value.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
                return uint.TryParse(value.Substring(2), System.Globalization.NumberStyles.HexNumber, null, out mask);
            return uint.TryParse(value, out mask);
        }

        public static string BuildGroundStationKey(string stationName, int antennaIndex)
        {
            return stationName + ":" + antennaIndex;
        }

        public void DeleteSubnet(int bit)
        {
            uint clearMask = ~(1u << bit);

            // -------- Vessel antennas --------
            foreach (var v in FlightGlobals.Vessels)
            {
                if (v?.Connection is RACommNetVessel cnv &&
                    cnv.Comm is RACommNode node)
                {
                    foreach (var ant in node.RAAntennaList)
                    {
                        ant.SubnetMask =
                            RASubnets.NormalizeMask(
                                ant.SubnetMask & clearMask);
                    }

                    cnv.DiscoverAntennas();
                }
            }

            // -------- Ground station antennas --------
            if (RACommNetScenario.GroundStations != null)
            {
                foreach (var kvp in RACommNetScenario.GroundStations)
                {
                    var station = kvp.Value;
                    if (station?.Comm == null) continue;

                    for (int i = 0; i < station.Comm.RAAntennaList.Count; i++)
                    {
                        var ant = station.Comm.RAAntennaList[i];
                        ant.SubnetMask =
                            RASubnets.NormalizeMask(
                                ant.SubnetMask & clearMask);
                    }
                }
            }

            subnetNames.Remove(bit);
            RequestNetworkRefreshDeferred();
        }

        public static void RequestNetworkRefreshDeferred()
        {
            if (refreshScheduled)
                return;

            refreshScheduled = true;
            Instance.StartCoroutine(DeferredNetworkRefresh());
        }

        private static IEnumerator DeferredNetworkRefresh()
        {
            // Wait until all UI actions settle
            yield return null;

            try
            {
                RACommNetScenario scen = RACommNetScenario.Instance as RACommNetScenario;
                if (scen?.Network != null)
                    scen.Network.InvalidateCache();

                if (FlightGlobals.ActiveVessel != null)
                    GameEvents.onVesselWasModified.Fire(FlightGlobals.ActiveVessel);
            }
            finally
            {
                refreshScheduled = false;
            }
        }

        #endregion
    }
    #endregion 

    #region Subnet Manager UI (IMGUI)
    // -------------------------------
    // Subnet Manager UI
    // -------------------------------
    internal class SubnetManagerUI : MonoBehaviour
    {
        private enum TopTab { Vessels, GroundStations }
        private enum VesselSortMode { Alphabetical, VesselType, RFBand, Subnet }
        private enum StationSortMode { Alphabetical, RFBand, Subnet }

        private class BodyNode
        {
            public CelestialBody Body;
            public int Depth;
            public int Count;
        }

        private class VesselRow
        {
            public Vessel Vessel;
            public RACommNode Node;
            public string BandSummary;
            public string SubnetSummary;
        }

        private class StationRow
        {
            public Network.RACommNetHome Station;
            public string Name;
            public int AntCount;
            public string BandSummary;
            public string SubnetSummary;
        }

        private class AntennaRow
        {
            public string Key;
            public RealAntenna Antenna;
            public int StationIndex = -1;
        }

        #region UI: States & Caches
        // -------- Subnet registry helpers --------
        private SubnetManagerScenario Registry => SubnetManagerScenario.Instance;
        private IEnumerable<KeyValuePair<int, string>> ActiveSubnets =>
            Registry != null
                ? Registry.Subnets.OrderBy(k => k.Key)
                : Enumerable.Empty<KeyValuePair<int, string>>();

        public bool Visible { get; set; }

        private Rect windowRect = new Rect(120, 80, 1460, 860);

        private Vector2 bodyScroll;
        private Vector2 vesselScroll;
        private Vector2 stationScroll;
        private Vector2 antennaScroll;
        private Vector2 subnetScroll;

        private TopTab tab = TopTab.Vessels;
        private VesselSortMode vesselSortMode = VesselSortMode.Alphabetical;
        private StationSortMode stationSortMode = StationSortMode.Alphabetical;

        private string searchText = string.Empty;
        private CelestialBody selectedBody;
        private bool bodyDropdownOpen;

        private bool subnetFilterDropdownOpen;

        private Vessel selectedVessel;
        private RACommNode selectedVesselNode;
        private Network.RACommNetHome selectedStation;

        private readonly HashSet<string> selectedAntennaKeys = new HashSet<string>();
        private uint workingMask = RASubnets.PublicBit;
        private uint baselineMask = RASubnets.PublicBit;

        private bool hasPendingChanges;
        private bool baselineMixed;

        private bool pendingDialogActive;
        private Action deferredDialog;

        // Filters (Vessels only)
        private readonly Dictionary<string, bool> rfBandFilterStates = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<int, bool> subnetFilterStates = new Dictionary<int, bool>();

        // Body icon caches
        private Texture2D texStar;
        private Texture2D texPlanet;
        private Texture2D texMoon;
        private readonly Dictionary<string, Texture2D> bodyIconCache = new Dictionary<string, Texture2D>(64);
        private Dictionary<string, string> kopernicusIconPathCache;

        // --- UI icon caches ---
        private Texture2D icoPlan;
        private Texture2D icoDish;
        private Texture2D icoOmni;

        private GUIContent gcPlan;
        private GUIContent gcDish;
        private GUIContent gcOmni;

        // Styles
        private GUIStyle rowButton;
        private GUIStyle headerLabel;
        private GUIStyle smallLabel;
        private GUIStyle bigLabel;
        private GUIStyle selectedBox;

        //sizingDefaults
        private float headerWidth = 1460;
        private float leftPanelWidth = 540;
        private float antennaPanelWidth = 600;
        private float subnetpanelWidth = 320;

        private void Awake()
        {
            Targeting.TextureTools.Initialize();
            EnsureBodyIcons();
            GameEvents.onGameSceneLoadRequested.Add(OnSceneChange);
        }

        private void OnDestroy()
        {
            GameEvents.onGameSceneLoadRequested.Remove(OnSceneChange);
        }

        private void OnSceneChange(GameScenes scene)
        {
            Visible = false;
        }

        public void ResetSelection()
        {
            selectedAntennaKeys.Clear();
            baselineMask = RASubnets.PublicBit;
            workingMask = baselineMask;
            baselineMixed = false;
            hasPendingChanges = false;
        }
        #endregion

        #region UI: Styles & Rendering
        private void OnGUI()
        {
            if (!Visible)
                return;

            GUI.skin = HighLogic.Skin;
            EnsureStyles();
            EnsureUIIcons();

            windowRect = ClickThruBlocker.GUILayoutWindow(GetHashCode(), windowRect, DrawWindow, "Subnet Manager", HighLogic.Skin.window);

            // Spawn deferred modal after window draw
            if (deferredDialog != null)
            {
                Action d = deferredDialog;
                deferredDialog = null;
                d.Invoke();
            }
        }

        private void DrawWindow(int id)
        {
            DrawHeader();
            GUILayout.Space(6);

            // Main panels row
            GUILayout.BeginHorizontal();
            DrawLeftPanel();
            DrawAntennaPanel();
            DrawSubnetPanel();
            GUILayout.EndHorizontal();

            GUILayout.Space(8);

            // Footer row (right-justified Close button)
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();

            if (GUILayout.Button("Close", GUILayout.Width(120)))
            {
                if (hasPendingChanges)
                    AttemptChangeContext(() => { Visible = false; }, "You have unapplied subnet changes.");
                else
                    Visible = false;
            }

            GUILayout.EndHorizontal();

            GUI.DragWindow();
        }


        // ============================================================
        // Header
        // ============================================================
        private void DrawHeader()
        {
            List<BodyNode> bodies = BuildBodyTree();

            GUILayout.BeginVertical(HighLogic.Skin.box);

            // Row 0: full width tabs
            GUILayout.BeginHorizontal();

            GUI.enabled = tab != TopTab.Vessels;
            if (GUILayout.Button("Vessels", GUILayout.ExpandWidth(true), GUILayout.Height(36)))
                AttemptChangeContext(() => { tab = TopTab.Vessels; subnetFilterDropdownOpen = false; ClearSelection(keepBodyFilter: true); }, "Switch to Vessels tab?");
            GUI.enabled = true;

            GUI.enabled = tab != TopTab.GroundStations;
            if (GUILayout.Button("Ground Stations", GUILayout.ExpandWidth(true), GUILayout.Height(36)))
                AttemptChangeContext(() => { tab = TopTab.GroundStations; subnetFilterDropdownOpen = false; ClearSelection(keepBodyFilter: true); }, "Switch to Ground Stations tab?");
            GUI.enabled = true;

            GUILayout.EndHorizontal();

            GUILayout.Space(6);

            // Row 1: Body >> Search >> Sort
            GUILayout.BeginHorizontal(HighLogic.Skin.box);

            GUILayout.Label("Body", GUILayout.Width(40));
            string bodyName = selectedBody != null ? GetDisplayBodyName(selectedBody) : "All";
            if (GUILayout.Button(bodyName, GUILayout.Width(220)))
                bodyDropdownOpen = !bodyDropdownOpen;

            GUILayout.Space(12);

            GUILayout.Label("Search", GUILayout.Width(60));
            searchText = GUILayout.TextField(searchText, GUILayout.Width(300));

            GUILayout.Space(12);

            GUILayout.Label("Sort", GUILayout.Width(40));
            if (tab == TopTab.Vessels)
            {
                if (GUILayout.Button(vesselSortMode.ToString(), GUILayout.Width(160)))
                    vesselSortMode = (VesselSortMode)(((int)vesselSortMode + 1) % Enum.GetValues(typeof(VesselSortMode)).Length);
            }
            else
            {
                if (GUILayout.Button(stationSortMode.ToString(), GUILayout.Width(160)))
                    stationSortMode = (StationSortMode)(((int)stationSortMode + 1) % Enum.GetValues(typeof(StationSortMode)).Length);
            }

            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();

            // Row 2: Body tree
            if (bodyDropdownOpen)
            {
                bodyScroll = GUILayout.BeginScrollView(bodyScroll, GUILayout.Height(260));

                if (GUILayout.Button("All", rowButton))
                    AttemptChangeContext(() => { selectedBody = null; bodyDropdownOpen = false; }, "Change body filter?");

                for (int i = 0; i < bodies.Count; i++)
                {
                    BodyNode n = bodies[i];
                    GUILayout.BeginHorizontal();
                    GUILayout.Label(IconForBody(n.Body), GUILayout.Width(20), GUILayout.Height(20));
                    string prefix = n.Depth == 0 ? "" : new string(' ', n.Depth * 3) + "└─ ";
                    string label = prefix + GetDisplayBodyName(n.Body) + " (" + n.Count + ")";
                    if (GUILayout.Button(label, rowButton))
                    {
                        CelestialBody b = n.Body;
                        AttemptChangeContext(() => { selectedBody = b; bodyDropdownOpen = false; }, "Change body filter?");
                    }
                    GUILayout.EndHorizontal();
                }

                GUILayout.EndScrollView();
            }

            // Row 3: Filters (Vessels only)
            if (tab == TopTab.Vessels)
            {
                List<VesselRow> basis = GetVisibleVessels(includeRfSubnetFiltering: false);
                EnsureFilterStateDictionaries(basis);

                GUILayout.BeginHorizontal(HighLogic.Skin.box);

                // Vessel type icons
                GUILayout.Label("Type", GUILayout.Width(40));
                foreach (VesselType vType in Targeting.TextureTools.vesselTypes)
                {
                    if (!Targeting.TextureTools.filterTextures.TryGetValue(vType, out Texture2D tex))
                        continue;
                    if (!Targeting.TextureTools.filterStates.ContainsKey(vType))
                        Targeting.TextureTools.filterStates[vType] = true;
                    Targeting.TextureTools.filterStates[vType] = GUILayout.Toggle(Targeting.TextureTools.filterStates[vType], tex, HighLogic.Skin.button, GUILayout.Width(28), GUILayout.Height(28));
                }

                // RF filter inline
                GUILayout.Space(10);
                GUILayout.Label("RF", GUILayout.Width(26));
                if (GUILayout.Button("All", GUILayout.Width(44)))
                    SetAllRfBandFilters(false);

                foreach (var kv in rfBandFilterStates.OrderBy(k => k.Key, StringComparer.OrdinalIgnoreCase))
                {
                    bool cur = kv.Value;
                    bool next = GUILayout.Toggle(cur, kv.Key, HighLogic.Skin.button, GUILayout.MinWidth(58));
                    if (next != cur)
                        rfBandFilterStates[kv.Key] = next;
                }

                // Subnet dropdown inline
                GUILayout.FlexibleSpace();
                GUILayout.Space(10);
                string subnetSummary = GetSubnetFilterSummary();
                if (GUILayout.Button("Subnet: " + subnetSummary, GUILayout.Width(240)))
                    subnetFilterDropdownOpen = !subnetFilterDropdownOpen;
                GUILayout.EndHorizontal();

                if (subnetFilterDropdownOpen)
                {
                    GUILayout.BeginVertical(HighLogic.Skin.box);

                    // Header row
                    GUILayout.BeginHorizontal();
                    GUILayout.Label("Subnet Filter", headerLabel);
                    GUILayout.FlexibleSpace();
                    GUILayout.EndHorizontal();

                    float buttonGap = 6f;
                    float buttonWidth = Mathf.Floor((headerWidth - 15 * buttonGap) / 16);

                    // Row 1: Public fills the row
                    GUILayout.BeginHorizontal();
                    {
                        bool cur = GetSubnetFilter(0);
                        bool next = GUILayout.Toggle(cur, "Public", HighLogic.Skin.button, GUILayout.Width(80));
                        if (next != cur) SetSubnetFilter(0, next);
                        GUILayout.FlexibleSpace();
                        if (GUILayout.Button("Clear", GUILayout.Width(80)))
                            SetAllSubnetFilters(false);
                        GUILayout.Space(10);
                        if (GUILayout.Button("↥", GUILayout.Width(80)))
                            subnetFilterDropdownOpen = false;
                        GUILayout.Space(10);
                    }
                    GUILayout.EndHorizontal();

                    GUILayout.Space(6);

                    // Row 2: Private SN List
                    foreach (var kvp in ActiveSubnets)
                    {
                        int bit = kvp.Key;
                        string name = kvp.Value;

                        bool cur = GetSubnetFilter(bit);
                        bool next = GUILayout.Toggle(cur, name, HighLogic.Skin.button, GUILayout.Width(buttonWidth));
                        if (next != cur)
                            SetSubnetFilter(bit, next);
                    }

                    GUILayout.EndVertical();
                }

            }

            GUILayout.EndVertical();
        }

        // ============================================================
        // Left panel
        // ============================================================
        private void DrawLeftPanel()
        {
            GUILayout.BeginVertical(GUILayout.Width(leftPanelWidth));
            if (tab == TopTab.Vessels)
                DrawVesselListPanel();
            else
                DrawGroundStationListPanel();
            GUILayout.EndVertical();
        }

        private void DrawVesselListPanel()
        {
            GUILayout.Label("Vessels", headerLabel);

            List<VesselRow> vessels = GetVisibleVessels(includeRfSubnetFiltering: true);

            float bandWidth = ComputeColumnWidth(vessels.Select(v => v.BandSummary), 110, 220);
            float subnetWidth = ComputeColumnWidth(vessels.Select(v => v.SubnetSummary), 90, 140); // narrow

            GUILayout.BeginHorizontal(HighLogic.Skin.box);
            GUILayout.Label("", GUILayout.Width(24));
            GUILayout.Label("Vessel", GUILayout.ExpandWidth(true));
            GUILayout.Label("Antennas", GUILayout.Width(70));
            GUILayout.Label("RF Bands", GUILayout.Width(bandWidth));
            GUILayout.Label("Subnets", GUILayout.Width(subnetWidth));
            GUILayout.EndHorizontal();

            bool needsScroll = vessels.Count > 14;
            if (needsScroll)
                vesselScroll = GUILayout.BeginScrollView(vesselScroll);

            for (int i = 0; i < vessels.Count; i++)
            {
                VesselRow row = vessels[i];
                bool isSelected = row.Vessel == selectedVessel;
                GUIStyle style = isSelected ? selectedBox : HighLogic.Skin.box;

                GUILayout.BeginHorizontal(style);

                if (Targeting.TextureTools.filterTextures.TryGetValue(row.Vessel.vesselType, out Texture2D vTex))
                    GUILayout.Label(vTex, GUILayout.Width(22), GUILayout.Height(22));
                else
                    GUILayout.Label("", GUILayout.Width(22));

                if (GUILayout.Button(row.Vessel.vesselName, rowButton, GUILayout.ExpandWidth(true)))
                {
                    Vessel v = row.Vessel;
                    RACommNode n = row.Node;
                    AttemptChangeContext(() => SelectVessel(v, n), "You have unapplied subnet changes.");
                }

                GUILayout.Label(row.Node.RAAntennaList.Count.ToString(), smallLabel, GUILayout.Width(70));
                GUILayout.Label(row.BandSummary, smallLabel, GUILayout.Width(bandWidth));
                GUILayout.Label(row.SubnetSummary, smallLabel, GUILayout.Width(subnetWidth));

                GUILayout.EndHorizontal();
            }

            if (needsScroll)
                GUILayout.EndScrollView();

            if (vessels.Count == 0)
                GUILayout.Label("No vessels match the current filters.");
        }

        private void DrawGroundStationListPanel()
        {
            GUILayout.Label("Ground Stations", headerLabel);

            List<StationRow> rows = GetVisibleStations();
            float bandWidth = ComputeColumnWidth(rows.Select(r => r.BandSummary), 110, 220);
            float subnetWidth = ComputeColumnWidth(rows.Select(r => r.SubnetSummary), 90, 160);

            GUILayout.BeginHorizontal(HighLogic.Skin.box);
            GUILayout.Label("Station", GUILayout.ExpandWidth(true));
            GUILayout.Label("Antennas", GUILayout.Width(70));
            GUILayout.Label("RF Bands", GUILayout.Width(bandWidth));
            GUILayout.Label("Subnets", GUILayout.Width(subnetWidth));
            GUILayout.EndHorizontal();

            bool needsScroll = rows.Count > 14;
            if (needsScroll)
                stationScroll = GUILayout.BeginScrollView(stationScroll);

            for (int i = 0; i < rows.Count; i++)
            {
                StationRow r = rows[i];
                bool isSelected = selectedStation == r.Station;
                GUIStyle style = isSelected ? selectedBox : HighLogic.Skin.box;

                GUILayout.BeginHorizontal(style);

                if (GUILayout.Button(r.Name, rowButton, GUILayout.ExpandWidth(true)))
                {
                    Network.RACommNetHome st = r.Station;
                    AttemptChangeContext(() => SelectStation(st), "You have unapplied subnet changes.");
                }

                GUILayout.Label(r.AntCount.ToString(), smallLabel, GUILayout.Width(70));
                GUILayout.Label(r.BandSummary, smallLabel, GUILayout.Width(bandWidth));
                GUILayout.Label(r.SubnetSummary, smallLabel, GUILayout.Width(subnetWidth));

                GUILayout.EndHorizontal();
            }

            if (needsScroll)
                GUILayout.EndScrollView();

            if (rows.Count == 0)
                GUILayout.Label("No stations match the current filters.");
        }

        // ============================================================
        // Antennas panel
        // ============================================================
        private void DrawAntennaPanel()
        {
            GUILayout.BeginVertical(GUILayout.Width(antennaPanelWidth));
            GUILayout.Label("Antennas", headerLabel);

            if (selectedVessel == null && selectedStation == null)
            {
                GUILayout.Label("Select a vessel or station.");
                GUILayout.EndVertical();
                return;
            }

            // Build once so the button can use current context/selection
            List<AntennaRow> rows = GetCurrentAntennaRows();

            // --- Single Planner button (context-based) ---
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();

            GUI.enabled = rows != null && rows.Count > 0;
            if (GUILayout.Button(new GUIContent("Open Planner", "Open Antenna Planning for the selected context"),
                                 GUILayout.Width(140), GUILayout.Height(26)))
            {
                OpenPlannerForContext(rows);
            }
            GUI.enabled = true;

            GUILayout.EndHorizontal();
            GUILayout.Space(6);

            // --- Table header  ---
            GUILayout.BeginHorizontal(HighLogic.Skin.box);
            GUILayout.Label("", GUILayout.Width(26)); // Sel (no heading)
            GUILayout.Label("", GUILayout.Width(24)); // icon
            GUILayout.Label("Antenna", GUILayout.Width(220));
            GUILayout.Label("RF Band", GUILayout.Width(80));
            GUILayout.Label("Subnet", GUILayout.Width(100));
            GUILayout.Label("Target", GUILayout.Width(100));
            GUILayout.EndHorizontal();

            antennaScroll = GUILayout.BeginScrollView(antennaScroll);

            for (int i = 0; i < rows.Count; i++)
            {
                AntennaRow r = rows[i];
                bool sel = selectedAntennaKeys.Contains(r.Key);
                GUIStyle style = sel ? selectedBox : HighLogic.Skin.box;

                GUILayout.BeginHorizontal(style);

                bool next = GUILayout.Toggle(sel, string.Empty, GUILayout.Width(26));
                if (next != sel)
                {
                    AttemptChangeContext(() =>
                    {
                        if (next) selectedAntennaKeys.Add(r.Key);
                        else selectedAntennaKeys.Remove(r.Key);

                        baselineMask = ComputeBaselineMask(out baselineMixed);
                        hasPendingChanges = (workingMask != baselineMask);
                    }, "You have unapplied subnet changes.");
                }

                // Antenna type icon
                var shapeGC = (r.Antenna.Shape == AntennaShape.Dish) ? gcDish : gcOmni;
                GUILayout.Label(shapeGC, GUILayout.Width(24), GUILayout.Height(24));

                // Name
                GUILayout.Label(r.Antenna.Name, bigLabel, GUILayout.Width(220));

                // Band
                string band = r.Antenna.RFBand != null ? r.Antenna.RFBand.name : "-";
                GUILayout.Label(band, GUILayout.Width(80));

                // Subnet summary
                GUILayout.Label(RASubnets.MaskSummary(r.Antenna.SubnetMask), GUILayout.Width(100));

                // Compact target name
                GUILayout.Label(GetCompactTargetName(r.Antenna), GUILayout.Width(100));

                GUILayout.EndHorizontal();
            }

            GUILayout.EndScrollView();

            // Selection helper buttons
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("All", GUILayout.Width(80)))
                AttemptChangeContext(SelectAllAntennas, "You have unapplied subnet changes.");

            if (GUILayout.Button("None", GUILayout.Width(80)))
                AttemptChangeContext(() =>
                {
                    selectedAntennaKeys.Clear();
                    baselineMask = ComputeBaselineMask(out baselineMixed);
                    workingMask = baselineMask;
                    hasPendingChanges = false;
                }, "You have unapplied subnet changes.");

            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();

            GUILayout.EndVertical();
        }

        // ============================================================
        // Subnets panel
        // ============================================================
        private void DrawSubnetPanel()
        {
            subnetScroll = GUILayout.BeginScrollView(subnetScroll);
            GUILayout.BeginVertical(GUILayout.Width(subnetpanelWidth));
            GUILayout.Label("Subnets", headerLabel);

            bool hasSelection = selectedAntennaKeys.Count > 0;

            // ======================================================
            // Public subnet (bit 0) — always present, exclusive
            // ======================================================
            GUILayout.BeginHorizontal();

            GUI.enabled = hasSelection;
            bool publicAssigned = workingMask == RASubnets.PublicBit;
            bool publicNext = GUILayout.Toggle(publicAssigned, string.Empty, GUILayout.Width(26));

            if (publicNext && !publicAssigned)
            {
                workingMask = RASubnets.PublicBit;
                hasPendingChanges = (workingMask != baselineMask);
            }
            GUI.enabled = true;

            GUILayout.Label("Public", GUILayout.ExpandWidth(true));

            GUILayout.EndHorizontal();

            GUILayout.Space(4);

            // ======================================================
            // Private subnets (bits 1..N)
            // ======================================================
            foreach (var kvp in ActiveSubnets)
            {
                int bit = kvp.Key;
                string name = kvp.Value;

                GUILayout.BeginHorizontal();

                // ---- Assignment toggle ----
                GUI.enabled = hasSelection;
                bool assigned = (workingMask & (1u << bit)) != 0u;
                bool nextAssigned = GUILayout.Toggle(assigned, string.Empty, GUILayout.Width(26));

                if (nextAssigned != assigned)
                {
                    if (nextAssigned)
                    {
                        workingMask &= ~RASubnets.PublicBit;
                        workingMask |= (1u << bit);
                    }
                    else
                    {
                        workingMask &= ~(1u << bit);
                        if ((workingMask & ~RASubnets.PublicBit) == 0u)
                            workingMask = RASubnets.PublicBit;
                    }

                    workingMask = RASubnets.NormalizeMask(workingMask);
                    hasPendingChanges = (workingMask != baselineMask);
                }
                GUI.enabled = true;

                // ---- Editable name ----
                string newName = GUILayout.TextField(name, GUILayout.ExpandWidth(true));
                if (newName != name)
                    Registry.RenameSubnet(bit, newName);

                // ---- Delete ----
                if (GUILayout.Button("−", GUILayout.Width(26)))
                {
                    int delBit = bit;
                    deferredDialog = () =>
                    {
                        PopupDialog.SpawnPopupDialog(
                            new Vector2(0.5f, 0.5f),
                            new Vector2(0.5f, 0.5f),
                            new MultiOptionDialog(
                                "ConfirmDeleteSubnet",
                                $"Delete subnet \"{name}\"?\n\nAll antennas on this subnet will be moved to Public.",
                                "Confirm Subnet Deletion",
                                HighLogic.UISkin,
                                new DialogGUIButton("Delete", () =>
                                {
                                    Registry.DeleteSubnet(delBit);
                                    baselineMask = ComputeBaselineMask(out baselineMixed);
                                    workingMask = baselineMask;
                                    hasPendingChanges = false;
                                }),
                                new DialogGUIButton("Cancel", () => { })
                            ),
                            false,
                            HighLogic.UISkin,
                            true
                        );
                    };
                }

                GUILayout.EndHorizontal();
            }

            GUILayout.Space(6);

            // ======================================================
            // Add subnet (with overflow guard)
            // ======================================================
            int freeBit = Enumerable.Range(1, RASubnets.MaxSubnets - 1)
                .FirstOrDefault(b => !Registry.HasSubnet(b));

            GUI.enabled = freeBit > 0;
            if (GUILayout.Button("+ Add Subnet"))
            {
                Registry.AddSubnet(freeBit, $"Subnet {freeBit}");
            }
            GUI.enabled = true;

            if (freeBit == 0)
                GUILayout.Label("Maximum number of subnets reached.", smallLabel);

            GUILayout.Space(8);
            GUILayout.Label(GetAppliedSummaryForSelection(), smallLabel);

            GUILayout.Space(8);
            GUILayout.BeginHorizontal();

            GUI.enabled = hasPendingChanges && hasSelection;
            if (GUILayout.Button("Apply", GUILayout.ExpandWidth(true)))
                ApplySubnet();
            GUI.enabled = true;

            GUI.enabled = hasPendingChanges;
            if (GUILayout.Button("Discard", GUILayout.ExpandWidth(true)))
                DiscardChanges();
            GUI.enabled = true;

            GUILayout.EndHorizontal();
            GUILayout.EndVertical();
            GUILayout.EndScrollView();
        }
        // ============================================================
        // Pending-change modal (deferred so it appears in front)
        // ============================================================
        private void AttemptChangeContext(Action action, string message)
        {
            if (!hasPendingChanges)
            {
                action?.Invoke();
                return;
            }

            if (pendingDialogActive)
                return;

            pendingDialogActive = true;
            string msg = string.IsNullOrEmpty(message) ? "You have unapplied subnet changes." : message;

            deferredDialog = () =>
            {
                PopupDialog.SpawnPopupDialog(
                    new Vector2(0.5f, 0.5f),
                    new Vector2(0.5f, 0.5f),
                    new MultiOptionDialog(
                        "SubnetManagerPendingChanges",
                        msg,
                        "Unapplied Changes",
                        HighLogic.UISkin,
                        new DialogGUIButton("Apply", () =>
                        {
                            pendingDialogActive = false;
                            ApplySubnet();
                            action?.Invoke();
                        }),
                        new DialogGUIButton("Discard", () =>
                        {
                            pendingDialogActive = false;
                            DiscardChanges();
                            action?.Invoke();
                        }),
                        new DialogGUIButton("Cancel", () =>
                        {
                            pendingDialogActive = false;
                        })
                    ),
                    false,
                    HighLogic.UISkin,
                    true
                );
            };
        }

        // ============================================================
        // Selection / Apply logic
        // ============================================================
        private void ClearSelection(bool keepBodyFilter)
        {
            selectedVessel = null;
            selectedVesselNode = null;
            selectedStation = null;
            selectedAntennaKeys.Clear();

            baselineMask = RASubnets.PublicBit;
            baselineMixed = false;
            workingMask = RASubnets.PublicBit;
            hasPendingChanges = false;

            pendingDialogActive = false;
            if (!keepBodyFilter)
                selectedBody = null;
        }

        private void SelectVessel(Vessel vessel, RACommNode node)
        {
            selectedVessel = vessel;
            selectedVesselNode = node;
            selectedStation = null;

            selectedAntennaKeys.Clear();
            for (int i = 0; i < node.RAAntennaList.Count; i++)
                selectedAntennaKeys.Add(BuildVesselAntennaKey(vessel, i));

            baselineMask = ComputeBaselineMask(out baselineMixed);
            workingMask = baselineMask;
            hasPendingChanges = false;
        }

        private void SelectStation(Network.RACommNetHome station)
        {
            selectedStation = station;
            selectedVessel = null;
            selectedVesselNode = null;

            selectedAntennaKeys.Clear();
            baselineMask = RASubnets.PublicBit;
            baselineMixed = false;
            workingMask = baselineMask;
            hasPendingChanges = false;
        }

        private void SelectAllAntennas()
        {
            selectedAntennaKeys.Clear();
            List<AntennaRow> rows = GetCurrentAntennaRows();
            for (int i = 0; i < rows.Count; i++)
                selectedAntennaKeys.Add(rows[i].Key);

            baselineMask = ComputeBaselineMask(out baselineMixed);
            workingMask = baselineMask;
            hasPendingChanges = false;
        }

        // Picks a source antenna from the current context and opens PlannerGUI.
        // Priority: first checked antenna -> first row antenna.
        private void OpenPlannerForContext(List<AntennaRow> rows)
        {
            RealAntenna source = null;

            // Prefer an explicitly checked antenna (deterministic: first key that resolves)
            if (selectedAntennaKeys != null && selectedAntennaKeys.Count > 0)
            {
                foreach (string key in selectedAntennaKeys)
                {
                    if (TryGetAntennaByKey(key, out RealAntenna ant) && ant != null)
                    {
                        source = ant;
                        break;
                    }
                }
            }

            // Fallback: first antenna in list
            if (source == null && rows != null && rows.Count > 0)
                source = rows[0].Antenna;

            if (source == null)
                return;

            LaunchPlanningGUI(source);
        }

        private uint ComputeBaselineMask(out bool mixed)
        {
            mixed = false;
            List<AntennaRow> rows = GetCurrentAntennaRows();
            uint? first = null;

            for (int i = 0; i < rows.Count; i++)
            {
                if (!selectedAntennaKeys.Contains(rows[i].Key))
                    continue;

                uint m = RASubnets.NormalizeMask(rows[i].Antenna.SubnetMask);
                if (!first.HasValue)
                    first = m;
                else if (first.Value != m)
                    mixed = true;
            }

            return first.HasValue ? first.Value : RASubnets.PublicBit;
        }

        private string GetAppliedSummaryForSelection()
        {
            if (selectedAntennaKeys.Count == 0)
                return "Applied: (none)";
            if (baselineMixed)
                return "Applied: Mixed";
            return "Applied: " + RASubnets.MaskSummary(baselineMask);
        }

        private void DiscardChanges()
        {
            workingMask = baselineMask;
            hasPendingChanges = false;
            Repaint();
        }

        private void ApplySubnet()
        {
            workingMask = RASubnets.NormalizeMask(workingMask);

            // Track which vessels we actually touched (don’t rebuild ALL vessels)
            HashSet<Guid> touchedVessels = new HashSet<Guid>();

            foreach (var key in selectedAntennaKeys)
            {
                if (!TryGetAntennaByKey(key, out RealAntenna ant) || ant == null)
                    continue;

                // Always update the live object (UI immediate)
                ant.SubnetMask = workingMask;

                if (key.StartsWith("V:"))
                {
                    // Persist to the owning module even if ant.Parent is null
                    if (TryResolveModuleForVesselAntenna(key, ant, out ModuleRealAntenna mra) && mra != null)
                    {
                        mra.SubnetMask = workingMask;
                        mra.SubnetSummary = RASubnets.MaskSummary(workingMask);
                        if (mra.RAAntenna != null)
                            mra.RAAntenna.SubnetMask = workingMask;
                    }
                    else
                    {
                        // --- SNAPSHOT BRANCH: unloaded/on-rails vessels ---
                        // In DiscoverAntennas() unloaded path, antennas are rebuilt from ProtoPartModuleSnapshot.moduleValues.
                        // If we don't update the snapshot, it will revert on the next rediscovery. [1](https://onedrive.live.com/?id=517162cd-e992-40d3-8ad4-59f37e4a74ba&cid=f4bbd1d82e299afd&web=1)
                        ProtoPartModuleSnapshot snap = null;

                        // RealAntennaDigital sets ParentSnapshot = snap in the unloaded path. [1](https://onedrive.live.com/?id=517162cd-e992-40d3-8ad4-59f37e4a74ba&cid=f4bbd1d82e299afd&web=1)
                        // We use reflection to avoid compile issues if the base type doesn't expose ParentSnapshot directly.
                        var prop = ant.GetType().GetProperty("ParentSnapshot", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                        if (prop != null)
                            snap = prop.GetValue(ant, null) as ProtoPartModuleSnapshot;

                        if (snap != null)
                        {
                            uint finalMask = RASubnets.NormalizeMask(workingMask);

                            // Persist the same field name ModuleRealAntenna saves (KSPField isPersistant = true) [2](https://onedrive.live.com/?id=5a678f7c-1943-4160-972f-5b650fcbcb74&cid=f4bbd1d82e299afd&web=1)
                            snap.moduleValues.SetValue(nameof(ModuleRealAntenna.SubnetMask), finalMask.ToString(), true);
                            snap.moduleValues.SetValue(nameof(ModuleRealAntenna.SubnetSummary), RASubnets.MaskSummary(finalMask), true);

                            Debug.Log($"[SubnetManagerUI] Updated snapshot SubnetMask for {snap.moduleName}");

                            // Update the transient runtime antenna too (so the current UI list reflects it immediately)
                            ant.SubnetMask = finalMask;
                        }
                        else
                        {
                            Debug.LogWarning($"[SubnetManagerUI] Could not resolve ModuleRealAntenna OR snapshot for key {key} / antenna {ant.Name}. Subnet will revert after rediscovery.");
                        }
                    }

                    // Remember vessel for targeted rebuild
                    var parts = key.Split(':');
                    if (parts.Length == 3 && Guid.TryParse(parts[1], out Guid vid))
                        touchedVessels.Add(vid);
                }
                else if (key.StartsWith("S:"))
                {
                    // Ground stations persist via scenario overrides (you already do this)
                    var parts = key.Split(':');
                    if (parts.Length == 3 && int.TryParse(parts[2], out int antIndex))
                    {
                        string stationName = parts[1];
                        Registry?.SetGroundStationAntennaOverride(stationName, antIndex, workingMask);
                    }
                }
            }

            // Rebuild ONLY the affected vessels (instead of every vessel)
            foreach (var v in FlightGlobals.Vessels)
            {
                if (v == null) continue;
                if (!touchedVessels.Contains(v.id)) continue;

                if (v.Connection is RACommNetVessel cnv && cnv.Comm is RACommNode)
                    cnv.DiscoverAntennas();
            }

            baselineMask = ComputeBaselineMask(out baselineMixed);
            workingMask = baselineMask;
            hasPendingChanges = false;

            SubnetManagerScenario.RequestNetworkRefresh();
        }

        private void Repaint()
        {
            // IMGUI repaints naturally, but toggling visibility forces refresh
            Visible = false;
            Visible = true;
        }
        #region Data providers
        // ============================================================
        // Data providers
        // ============================================================
        private List<VesselRow> GetVisibleVessels(bool includeRfSubnetFiltering)
        {
            IEnumerable<VesselRow> vessels =
                FlightGlobals.Vessels
                    .Where(v => v != null && v.Connection is RACommNetVessel)
                    .Select(v => new VesselRow { Vessel = v, Node = v.Connection.Comm as RACommNode })
                    .Where(v => v.Node != null && v.Node.RAAntennaList != null && v.Node.RAAntennaList.Count > 0);

            // Search: name OR RF summary OR subnet summary
            if (!string.IsNullOrEmpty(searchText))
            {
                vessels = vessels.Where(v =>
                {
                    string subs = SummarizeVesselSubnets(v.Node);
                    string bands = SummarizeVesselRFBands(v.Node);
                    return v.Vessel.vesselName.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0
                        || subs.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0
                        || bands.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0;
                });
            }
            else if (selectedBody != null)
            {
                vessels = vessels.Where(v => v.Vessel.mainBody == selectedBody);
            }

            // Type filter
            vessels = vessels.Where(v =>
                Targeting.TextureTools.filterStates.TryGetValue(v.Vessel.vesselType, out bool on) ? on : true);

            List<VesselRow> list = vessels.ToList();
            for (int i = 0; i < list.Count; i++)
            {
                list[i].BandSummary = SummarizeVesselRFBands(list[i].Node);
                list[i].SubnetSummary = SummarizeVesselSubnets(list[i].Node);
            }

            // RF band + subnet filtering
            if (tab == TopTab.Vessels && includeRfSubnetFiltering)
            {
                if (AnyRfBandFilterOn())
                {
                    list = list.Where(v =>
                        v.Node.RAAntennaList.Any(a => a.RFBand != null && rfBandFilterStates.TryGetValue(a.RFBand.name, out bool on) && on))
                        .ToList();
                }

                if (AnySubnetFilterOn())
                {
                    list = list.Where(v =>
                    {
                        foreach (RealAntenna a in v.Node.RAAntennaList)
                        {
                            uint m = RASubnets.NormalizeMask(a.SubnetMask);
                            if (GetSubnetFilter(0) && (m & RASubnets.PublicBit) != 0u)
                                return true;
                            for (int i = 1; i < RASubnets.MaxSubnets; i++)
                                if (GetSubnetFilter(i) && (m & (1u << i)) != 0u)
                                    return true;
                        }
                        return false;
                    }).ToList();
                }
            }

            // Sorting
            switch (vesselSortMode)
            {
                case VesselSortMode.VesselType:
                    list = list.OrderBy(v => v.Vessel.vesselType).ThenBy(v => v.Vessel.vesselName).ToList();
                    break;
                case VesselSortMode.RFBand:
                    list = list.OrderBy(v => v.BandSummary).ThenBy(v => v.Vessel.vesselName).ToList();
                    break;
                case VesselSortMode.Subnet:
                    list = list.OrderBy(v => v.SubnetSummary).ThenBy(v => v.Vessel.vesselName).ToList();
                    break;
                default:
                    list = list.OrderBy(v => v.Vessel.vesselName).ToList();
                    break;
            }

            return list;
        }

        private List<StationRow> GetVisibleStations()
        {
            IEnumerable<Network.RACommNetHome> stations = RACommNetScenario.GroundStations != null
                ? RACommNetScenario.GroundStations.Values.Where(x => x != null && x.Comm != null)
                : Enumerable.Empty<Network.RACommNetHome>();

            // Search: name OR RF summary OR subnet summary
            if (!string.IsNullOrEmpty(searchText))
            {
                stations = stations.Where(s =>
                {
                    string name = s.displaynodeName ?? s.nodeName;
                    string subs = SummarizeStationSubnets(s);
                    string bands = SummarizeStationRFBands(s);
                    return name.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0
                        || subs.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0
                        || bands.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0;
                });
            }
            else if (selectedBody != null)
            {
                stations = stations.Where(s => s.Comm.ParentBody == selectedBody);
            }

            List<StationRow> rows = new List<StationRow>();
            foreach (Network.RACommNetHome s in stations)
            {
                rows.Add(new StationRow
                {
                    Station = s,
                    Name = s.displaynodeName ?? s.nodeName,
                    AntCount = s.Comm.RAAntennaList.Count,
                    BandSummary = SummarizeStationRFBands(s),
                    SubnetSummary = SummarizeStationSubnets(s)
                });
            }

            switch (stationSortMode)
            {
                case StationSortMode.RFBand:
                    return rows.OrderBy(r => r.BandSummary)
                               .ThenBy(r => r.Name)
                               .ToList();

                case StationSortMode.Subnet:
                    return rows.OrderBy(r => r.SubnetSummary)
                               .ThenBy(r => r.Name)
                               .ToList();

                default:
                    return rows.OrderBy(r => r.Name).ToList();
            }
        }

        private List<AntennaRow> GetCurrentAntennaRows()
        {
            List<AntennaRow> rows = new List<AntennaRow>();

            if (selectedVessel != null && selectedVesselNode != null)
            {
                for (int i = 0; i < selectedVesselNode.RAAntennaList.Count; i++)
                    rows.Add(new AntennaRow { Key = BuildVesselAntennaKey(selectedVessel, i), Antenna = selectedVesselNode.RAAntennaList[i] });
            }
            else if (selectedStation != null && selectedStation.Comm != null)
            {
                for (int i = 0; i < selectedStation.Comm.RAAntennaList.Count; i++)
                    rows.Add(new AntennaRow { Key = BuildStationAntennaKey(selectedStation, i), Antenna = selectedStation.Comm.RAAntennaList[i], StationIndex = i });
            }

            return rows;
        }
        #endregion

        #region Helper functions
        // ----------------------------------------------------------------
        // Helpers
        // ----------------------------------------------------------------
        private void LaunchPlanningGUI(RealAntenna antenna)
        {
            if (antenna == null)
                return;

            var parentModule = antenna.Parent as ModuleRealAntenna; // may be null, that's OK

            // Avoid spawning duplicates for the same part antenna
            var existing = FindObjectsOfType<PlannerGUI>()
                .FirstOrDefault(pg => pg != null && pg.primaryAntenna == antenna);

            if (existing != null)
            {
                existing.RequestUpdate = true;
                return;
            }

            var go = new GameObject($"{antenna.Name}-Planning");
            DontDestroyOnLoad(go);

            var planner = go.AddComponent<PlannerGUI>();
            planner.primaryAntenna = antenna;

            var homes = (RACommNetScenario.GroundStations != null)
                ? RACommNetScenario.GroundStations.Values.Where(x => x != null && x.Comm is RACommNode)
                : Enumerable.Empty<Network.RACommNetHome>();

            planner.fixedAntenna =
                planner.GetBestMatchingGroundStation(antenna, homes) is RealAntenna bestDSN
                    ? bestDSN
                    : antenna;

            // Provide PAW-equivalent context for cleanup/updates
            planner.parentPartModule = parentModule; // may be null

            planner.RequestUpdate = true;
        }

        private bool TryResolveModuleForVesselAntenna(string key, RealAntenna ant, out ModuleRealAntenna mra)
        {
            mra = null;
            if (ant == null || string.IsNullOrEmpty(key) || !key.StartsWith("V:"))
                return false;

            var parts = key.Split(':');
            if (parts.Length != 3) return false;

            if (!Guid.TryParse(parts[1], out Guid vesselId))
                return false;

            Vessel v = FlightGlobals.Vessels.FirstOrDefault(x => x != null && x.id == vesselId);
            if (v == null) return false;

            // Fast path: if Parent exists, use it
            mra = ant.Parent as ModuleRealAntenna;
            if (mra != null) return true;

            // Otherwise, search vessel parts for a matching ModuleRealAntenna.
            // Match by antenna identity where possible, else by stable properties.
            string antName = ant.Name ?? string.Empty;
            string bandName = ant.RFBand != null ? ant.RFBand.name : string.Empty;
            var shape = ant.Shape;

            foreach (Part p in v.parts)
            {
                if (p == null) continue;
                var mods = p.FindModulesImplementing<ModuleRealAntenna>();
                if (mods == null) continue;

                for (int i = 0; i < mods.Count; i++)
                {
                    var cand = mods[i];
                    if (cand == null) continue;

                    // If cand exposes the same RealAntenna instance, we’re done
                    if (ReferenceEquals(cand.RAAntenna, ant))
                    {
                        mra = cand;
                        return true;
                    }

                    // Fallback: match by name + shape + band (good enough for most craft)
                    var ra = cand.RAAntenna;
                    if (ra == null) continue;

                    string candBand = ra.RFBand != null ? ra.RFBand.name : string.Empty;

                    if (string.Equals(ra.Name ?? string.Empty, antName, StringComparison.Ordinal) &&
                        ra.Shape == shape &&
                        string.Equals(candBand, bandName, StringComparison.Ordinal))
                    {
                        mra = cand;
                        return true;
                    }
                }
            }

            return false;
        }

        // ============================================================
        // Styles 
        // ============================================================
        private void EnsureStyles()
        {
            if (rowButton != null)
                return;

            rowButton = new GUIStyle(HighLogic.Skin.button) { alignment = TextAnchor.MiddleLeft };
            headerLabel = new GUIStyle(HighLogic.Skin.label) { fontStyle = FontStyle.Bold };
            smallLabel = new GUIStyle(HighLogic.Skin.label) { fontSize = 11 };
            bigLabel = new GUIStyle(HighLogic.Skin.label) { fontSize = 14, fontStyle = FontStyle.Bold };
            selectedBox = new GUIStyle(HighLogic.Skin.box);
            selectedBox.normal.background = selectedBox.active.background;
        }

        // ============================================================
        // Column sizing
        // ============================================================
        private float ComputeColumnWidth(IEnumerable<string> values, float min, float max)
        {
            float widest = min;
            try
            {
                foreach (string s in values)
                {
                    if (string.IsNullOrEmpty(s))
                        continue;

                    Vector2 size = smallLabel.CalcSize(new GUIContent(s));
                    widest = Mathf.Max(widest, size.x + 8f);
                    if (widest >= max)
                        return max;
                }
            }
            catch (Exception)
            {
            }

            return Mathf.Clamp(widest, min, max);
        }
        #endregion

        private string GetCompactTargetName(RealAntenna antenna)
        {
            if (antenna?.Target == null)
                return string.Empty;

            try
            {
                object target = antenna.Target;

                if (target is Vessel v)
                    return v.vesselName;

                if (target is CelestialBody b)
                    return b.bodyName;

                Type t = target.GetType();

                var vProp = t.GetProperty("Vessel");
                if (vProp?.GetValue(target) is Vessel vv)
                    return vv.vesselName;

                var bProp = t.GetProperty("Body");
                if (bProp?.GetValue(target) is CelestialBody bb)
                    return bb.bodyName;

                string s = target.ToString();
                int idx = s.IndexOf('(');
                return idx > 0 ? s.Substring(0, idx).Trim() : s;
            }
            catch
            {
                return string.Empty;
            }
        }
        private bool TryGetAntennaByKey(string key, out RealAntenna antenna)
        {
            antenna = null;

            // Vessel antenna
            if (key.StartsWith("V:"))
            {
                var parts = key.Split(':');
                if (parts.Length != 3) return false;

                if (Guid.TryParse(parts[1], out Guid vesselId) &&
                    int.TryParse(parts[2], out int index))
                {
                    Vessel v = FlightGlobals.Vessels.FirstOrDefault(x => x.id == vesselId);
                    if (v?.Connection is RACommNetVessel cnv &&
                        cnv.Comm is RACommNode node &&
                        index >= 0 && index < node.RAAntennaList.Count)
                    {
                        antenna = node.RAAntennaList[index];
                        return true;
                    }
                }
            }

            // Ground station antenna
            if (key.StartsWith("S:"))
            {
                var parts = key.Split(':');
                if (parts.Length != 3) return false;

                string stationName = parts[1];
                if (int.TryParse(parts[2], out int index) &&
                    RACommNetScenario.GroundStations != null &&
                    RACommNetScenario.GroundStations.TryGetValue(stationName, out var station) &&
                    index >= 0 && index < station.Comm.RAAntennaList.Count)
                {
                    antenna = station.Comm.RAAntennaList[index];
                    return true;
                }
            }

            return false;
        }
        #endregion

        #region Filter helpers
        // ============================================================
        // Filter helpers
        // ============================================================
        private void EnsureFilterStateDictionaries(List<VesselRow> basis)
        {
            HashSet<string> bands = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < basis.Count; i++)
            {
                foreach (RealAntenna a in basis[i].Node.RAAntennaList)
                {
                    if (a.RFBand != null && !string.IsNullOrEmpty(a.RFBand.name))
                        bands.Add(a.RFBand.name);
                }
            }

            foreach (string k in rfBandFilterStates.Keys.ToList())
                if (!bands.Contains(k))
                    rfBandFilterStates.Remove(k);
            foreach (string b in bands)
                if (!rfBandFilterStates.ContainsKey(b))
                    rfBandFilterStates[b] = false;


            // Ensure Public filter exists
            if (!subnetFilterStates.ContainsKey(0))
                subnetFilterStates[0] = false;

            // Ensure filters only for existing subnets
            foreach (var kvp in ActiveSubnets)
            {
                if (!subnetFilterStates.ContainsKey(kvp.Key))
                    subnetFilterStates[kvp.Key] = false;
            }

            // Remove stale filters for deleted subnets
            foreach (int k in subnetFilterStates.Keys.ToList())
            {
                if (k != 0 && (Registry == null || !Registry.HasSubnet(k)))
                    subnetFilterStates.Remove(k);
            }

            foreach (int k in subnetFilterStates.Keys.ToList())
            {
                if (k != 0 && (Registry == null || !Registry.HasSubnet(k)))
                    subnetFilterStates.Remove(k);
            }

        }

        private bool AnyRfBandFilterOn() => rfBandFilterStates.Any(kv => kv.Value);
        private bool AnySubnetFilterOn() => subnetFilterStates.Any(kv => kv.Value);

        private void SetAllRfBandFilters(bool value)
        {
            foreach (string k in rfBandFilterStates.Keys.ToList())
                rfBandFilterStates[k] = value;
        }

        private void SetAllSubnetFilters(bool value)
        {
            foreach (int k in subnetFilterStates.Keys.ToList())
                subnetFilterStates[k] = value;
        }

        private bool GetSubnetFilter(int idx) => subnetFilterStates.TryGetValue(idx, out bool v) && v;
        private void SetSubnetFilter(int idx, bool v) => subnetFilterStates[idx] = v;

        private string GetSubnetFilterSummary()
        {
            List<string> parts = new List<string>();

            if (GetSubnetFilter(0))
                parts.Add("Public");

            foreach (var kvp in ActiveSubnets)
                if (GetSubnetFilter(kvp.Key))
                    parts.Add(kvp.Value);

            if (parts.Count == 0) return "All";
            if (parts.Count <= 3) return string.Join(",", parts);
            return parts[0] + "," + parts[1] + ",+" + (parts.Count - 2);
        }
        #endregion

        #region Summaries
        // ============================================================
        // Summaries
        // ============================================================
        private string SummarizeVesselSubnets(RACommNode node)
        {
            return string.Join(",", node.RAAntennaList.Select(a => RASubnets.MaskSummary(a.SubnetMask)).Distinct().ToArray());
        }

        private string SummarizeVesselRFBands(RACommNode node)
        {
            return string.Join(",", node.RAAntennaList
                .Where(a => a.RFBand != null && !string.IsNullOrEmpty(a.RFBand.name))
                .Select(a => a.RFBand.name)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(s => s, StringComparer.OrdinalIgnoreCase)
                .ToArray());
        }

        private string SummarizeStationSubnets(Network.RACommNetHome station)
        {
            return string.Join(",", station.Comm.RAAntennaList.Select(a => RASubnets.MaskSummary(a.SubnetMask)).Distinct().ToArray());
        }

        private string SummarizeStationRFBands(Network.RACommNetHome station)
        {
            return string.Join(",", station.Comm.RAAntennaList
                .Where(a => a.RFBand != null && !string.IsNullOrEmpty(a.RFBand.name))
                .Select(a => a.RFBand.name)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(s => s, StringComparer.OrdinalIgnoreCase)
                .ToArray());
        }
        #endregion

        #region Body tree
        // ============================================================
        // Body tree (includes moons)
        // ============================================================
        private List<BodyNode> BuildBodyTree()
        {
            // Build included bodies and per-body counts once (avoids repeated enumeration inside recursion).
            var included = new HashSet<CelestialBody>();
            var counts = new Dictionary<CelestialBody, int>();

            if (tab == TopTab.Vessels)
            {
                var visible = GetVisibleVessels(includeRfSubnetFiltering: false);
                for (int i = 0; i < visible.Count; i++)
                {
                    var body = visible[i].Vessel.mainBody;
                    AddBodyChain(body, included);
                    if (body != null)
                        counts[body] = counts.TryGetValue(body, out int c) ? (c + 1) : 1;
                }
            }
            else
            {
                if (RACommNetScenario.GroundStations != null)
                {
                    foreach (var s in RACommNetScenario.GroundStations.Values)
                    {
                        var body = (s != null && s.Comm != null) ? s.Comm.ParentBody : null;
                        AddBodyChain(body, included);
                        if (body != null)
                            counts[body] = counts.TryGetValue(body, out int c) ? (c + 1) : 1;
                    }
                }
            }

            List<CelestialBody> roots = FlightGlobals.Bodies
                .Where(b => b != null && included.Contains(b) && GetParentBody(b) == null)
                .OrderBy(b => GetDisplayBodyName(b), StringComparer.OrdinalIgnoreCase)
                .ToList();

            List<BodyNode> res = new List<BodyNode>();
            for (int i = 0; i < roots.Count; i++)
                AppendBodyNode(res, roots[i], 0, included, counts);

            return res;
        }

        private void AddBodyChain(CelestialBody body, HashSet<CelestialBody> set)
        {
            while (body != null)
            {
                if (!set.Add(body))
                    break;
                body = GetParentBody(body);
            }
        }

        private void AppendBodyNode(List<BodyNode> res, CelestialBody body, int depth, HashSet<CelestialBody> included, Dictionary<CelestialBody, int> counts)
        {
            int count = 0;
            if (body != null)
                counts.TryGetValue(body, out count);

            res.Add(new BodyNode { Body = body, Depth = depth, Count = count });

            List<CelestialBody> children = FlightGlobals.Bodies
                .Where(b => b != null && included.Contains(b) && GetParentBody(b) == body)
                .OrderBy(b => GetDisplayBodyName(b), StringComparer.OrdinalIgnoreCase)
                .ToList();

            for (int i = 0; i < children.Count; i++)
                AppendBodyNode(res, children[i], depth + 1, included, counts);
        }

        private CelestialBody GetParentBody(CelestialBody body)
        {
            if (body == null) return null;
            try
            {
                if (body.orbit != null && body.orbit.referenceBody != null)
                    return body.orbit.referenceBody;
                if (body.orbitDriver != null && body.orbitDriver.orbit != null && body.orbitDriver.orbit.referenceBody != null)
                    return body.orbitDriver.orbit.referenceBody;
            }
            catch (Exception)
            {
            }
            return null;
        }

        // ============================================================
        // Safe Sun/Kerbol display naming
        // ============================================================
        private string GetDisplayBodyName(CelestialBody body)
        {
            if (body == null)
                return string.Empty;

            if (body.isStar && string.Equals(body.bodyName, "Sun", StringComparison.OrdinalIgnoreCase) && IsStockKerbolSystem())
                return "Kerbol";

            return body.bodyName;
        }

        private bool IsStockKerbolSystem()
        {
            try
            {
                CelestialBody kerbin = FlightGlobals.GetBodyByName("Kerbin");
                if (kerbin == null || kerbin.orbit == null || kerbin.orbit.referenceBody == null)
                    return false;

                bool kerbinOrbitsSun = string.Equals(kerbin.orbit.referenceBody.bodyName, "Sun", StringComparison.OrdinalIgnoreCase);
                bool hasEarth = FlightGlobals.GetBodyByName("Earth") != null;
                return kerbinOrbitsSun && !hasEarth;
            }
            catch (Exception)
            {
                return false;
            }
        }

        // ============================================================
        // Body icons (Kopernicus + OrbitIconsPack + sprite fallback)
        // ============================================================
        private void EnsureBodyIcons()
        {
            if (texStar != null)
                return;

            texStar = LoadIconFromSprites(new[] { "OrbitIcons_Sun", "OrbitIcons_Star", "OrbitIcons_S" });
            texPlanet = LoadIconFromSprites(new[] { "OrbitIcons_Planet", "OrbitIcons_AT", "OrbitIcons_GG", "OrbitIcons_Unknown" });
            texMoon = LoadIconFromSprites(new[] { "OrbitIcons_Moon", "OrbitIcons_T", "OrbitIcons_Unknown" });

            if (texStar == null) texStar = MakeSolidTex(new Color(1f, 0.85f, 0.15f, 1f));
            if (texPlanet == null) texPlanet = MakeSolidTex(new Color(0.25f, 0.6f, 1f, 1f));
            if (texMoon == null) texMoon = MakeSolidTex(new Color(0.75f, 0.75f, 0.8f, 1f));
        }

        private Texture2D LoadIconFromSprites(string[] preferredSpriteNames)
        {
            try
            {
                Sprite[] sprites = Resources.FindObjectsOfTypeAll<Sprite>();
                if (sprites == null || sprites.Length == 0)
                    return null;

                for (int i = 0; i < preferredSpriteNames.Length; i++)
                {
                    string name = preferredSpriteNames[i];
                    Sprite s = sprites.FirstOrDefault(x => x != null && x.name == name);
                    if (s != null)
                        return Targeting.TextureTools.TextureFromSprite(s);
                }
            }
            catch (Exception)
            {
            }
            return null;
        }

        private Texture2D MakeSolidTex(Color c)
        {
            Texture2D t = new Texture2D(12, 12, TextureFormat.RGBA32, false);
            Color[] pix = new Color[12 * 12];
            for (int i = 0; i < pix.Length; i++) pix[i] = c;
            t.SetPixels(pix);
            t.Apply(false, true);
            return t;
        }

        private Texture2D IconForBody(CelestialBody body)
        {
            if (body == null)
                return texPlanet;

            if (bodyIconCache.TryGetValue(body.bodyName, out Texture2D cached) && cached != null)
                return cached;

            Texture2D custom = TryLoadOrbitIconTexture(body);
            if (custom != null)
            {
                bodyIconCache[body.bodyName] = custom;
                return custom;
            }

            if (body.isStar)
                return texStar;

            CelestialBody parent = GetParentBody(body);
            if (parent != null && parent.isStar)
                return texPlanet;

            return texMoon;
        }

        private Texture2D TryLoadOrbitIconTexture(CelestialBody body)
        {
            string path = TryGetOrbitIconPathFromRuntime(body);

            if (string.IsNullOrEmpty(path))
            {
                EnsureKopernicusIconPathCache();
                if (kopernicusIconPathCache != null && kopernicusIconPathCache.TryGetValue(body.bodyName, out string cfgPath))
                    path = cfgPath;
            }

            if (string.IsNullOrEmpty(path))
            {
                string abbr = DetermineOrbitIconsPackAbbreviation(body);
                Texture2D oip = TryLoadOrbitIconsPackIcon(abbr);
                if (oip != null)
                    return oip;
            }

            if (string.IsNullOrEmpty(path))
                return null;

            string normalized = NormalizeGameDatabaseTexturePath(path);
            if (string.IsNullOrEmpty(normalized))
                return null;

            return GameDatabase.Instance != null ? GameDatabase.Instance.GetTexture(normalized, false) : null;
        }

        private string TryGetOrbitIconPathFromRuntime(CelestialBody body)
        {
            try
            {
                object orbitObj = body.orbit;
                if (orbitObj == null && body.orbitDriver != null)
                    orbitObj = body.orbitDriver.orbit;
                if (orbitObj == null)
                    return null;

                Type t = orbitObj.GetType();
                PropertyInfo p = t.GetProperty("iconTexture", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (p != null && p.PropertyType == typeof(string))
                    return p.GetValue(orbitObj, null) as string;

                FieldInfo f = t.GetField("iconTexture", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (f != null && f.FieldType == typeof(string))
                    return f.GetValue(orbitObj) as string;

                p = t.GetProperty("iconTexturePath", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (p != null && p.PropertyType == typeof(string))
                    return p.GetValue(orbitObj, null) as string;

                f = t.GetField("iconTexturePath", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (f != null && f.FieldType == typeof(string))
                    return f.GetValue(orbitObj) as string;
            }
            catch (Exception)
            {
            }
            return null;
        }

        private void EnsureKopernicusIconPathCache()
        {
            if (kopernicusIconPathCache != null)
                return;

            kopernicusIconPathCache = new Dictionary<string, string>(64);
            if (GameDatabase.Instance == null)
                return;

            try
            {
                ConfigNode[] roots = GameDatabase.Instance.GetConfigNodes("Kopernicus");
                if (roots == null)
                    return;

                for (int r = 0; r < roots.Length; r++)
                {
                    ConfigNode root = roots[r];
                    if (root == null)
                        continue;

                    ConfigNode[] bodies = root.GetNodes("Body");
                    if (bodies == null)
                        continue;

                    for (int b = 0; b < bodies.Length; b++)
                    {
                        ConfigNode bodyNode = bodies[b];
                        if (bodyNode == null)
                            continue;

                        string bodyName = bodyNode.GetValue("name");
                        if (string.IsNullOrEmpty(bodyName))
                            continue;

                        ConfigNode orbit = bodyNode.GetNode("Orbit");
                        if (orbit == null)
                            continue;

                        string iconPath = orbit.GetValue("iconTexture");
                        if (string.IsNullOrEmpty(iconPath))
                            continue;

                        if (!kopernicusIconPathCache.ContainsKey(bodyName))
                            kopernicusIconPathCache.Add(bodyName, iconPath);
                    }
                }
            }
            catch (Exception)
            {
            }
        }

        private string NormalizeGameDatabaseTexturePath(string raw)
        {
            if (string.IsNullOrEmpty(raw))
                return null;

            string s = raw.Trim();
            s = s.Replace('\\', '/');
            if (s.StartsWith("GameData/", StringComparison.OrdinalIgnoreCase))
                s = s.Substring("GameData/".Length);

            int q = s.IndexOf('?');
            if (q >= 0)
                s = s.Substring(0, q);

            string ext = Path.GetExtension(s);
            if (!string.IsNullOrEmpty(ext))
                s = s.Substring(0, s.Length - ext.Length);

            return s;
        }

        private Texture2D TryLoadOrbitIconsPackIcon(string typeAbbreviation)
        {
            if (string.IsNullOrEmpty(typeAbbreviation) || GameDatabase.Instance == null)
                return null;

            string url = "OrbitIconsPack/PluginData/Icon_" + typeAbbreviation;
            try
            {
                if (GameDatabase.Instance.ExistsTexture(url))
                    return GameDatabase.Instance.GetTexture(url, false);
            }
            catch (Exception)
            {
            }
            return null;
        }

        private string DetermineOrbitIconsPackAbbreviation(CelestialBody body)
        {
            if (body == null)
                return "T";
            if (body.isStar)
                return "S";

            bool hasAtmosphere = false;
            bool hasOcean = false;
            bool hasPqs = true;
            try
            {
                hasAtmosphere = body.atmosphere;
                hasOcean = body.ocean;
                hasPqs = body.pqsController != null;
            }
            catch (Exception)
            {
            }

            string baseType;
            if (hasAtmosphere && !hasPqs) baseType = "GG";
            else if (hasOcean) baseType = "O";
            else if (hasAtmosphere) baseType = "AT";
            else baseType = "T";

            if (HasRings(body) && !baseType.StartsWith("R", StringComparison.Ordinal))
                baseType = "R" + baseType;

            return baseType;
        }

        private bool HasRings(CelestialBody body)
        {
            if (body == null)
                return false;

            try
            {
                Type t = body.GetType();
                var prop = t.GetProperty("Rings", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (prop != null)
                {
                    object v = prop.GetValue(body, null);
                    if (v is System.Collections.ICollection c) return c.Count > 0;
                    if (v is System.Collections.IEnumerable e) return e.GetEnumerator().MoveNext();
                }
                var field = t.GetField("Rings", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (field != null)
                {
                    object v = field.GetValue(body);
                    if (v is System.Collections.ICollection c) return c.Count > 0;
                    if (v is System.Collections.IEnumerable e) return e.GetEnumerator().MoveNext();
                }
            }
            catch (Exception)
            {
            }

            return false;
        }

        //UI Icons
        private void EnsureUIIcons()
        {
            if (gcPlan != null) return;

            // Paths are GameData-relative and WITHOUT extension.
            icoPlan = GameDatabase.Instance.GetTexture("RealAntennas/plan", false);
            icoDish = GameDatabase.Instance.GetTexture("RealAntennas/dish", false);
            icoOmni = GameDatabase.Instance.GetTexture("RealAntennas/omni", false);

            // Final fallback (never null) — prevents invisible controls if textures missing
            if (icoPlan == null) icoPlan = Texture2D.whiteTexture;
            if (icoDish == null) icoDish = Texture2D.whiteTexture;
            if (icoOmni == null) icoOmni = Texture2D.whiteTexture;

            gcPlan = new GUIContent(icoPlan, "Open Antenna Planning\nAnalyze link quality / signal strength");
            gcDish = new GUIContent(icoDish, "Dish antenna");
            gcOmni = new GUIContent(icoOmni, "Omni antenna");
        }

        private string BuildVesselAntennaKey(Vessel vessel, int index) => "V:" + vessel.id + ":" + index;
        private string BuildStationAntennaKey(Network.RACommNetHome station, int index) => "S:" + station.nodeName + ":" + index;
        #endregion
    }
    #endregion
}